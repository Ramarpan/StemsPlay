//
//  StemsPlayApp.swift
//  StemsPlay
//
//  Created by Ramarpan on 19/01/26.
//

import SwiftUI

@main
struct StemsPlayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
