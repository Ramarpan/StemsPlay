import SwiftUI

private let controlColumnWidth: CGFloat = 90
private let waveformHeight: CGFloat = 60
private let playheadWidth: CGFloat = 2




struct ContentView: View {

    @StateObject private var mixerVM: MixerViewModel

    init() {
        let engine = StemAudioEngine()
        _mixerVM = StateObject(wrappedValue: MixerViewModel(engine: engine))
    }


    var body: some View {
        VStack(spacing: 20) {

            Text("Stems Play")
                .font(.title)

            HStack(spacing: 12) {
                Button("Load Folder") {
                    let panel = NSOpenPanel()
                    panel.canChooseFiles = false
                    panel.canChooseDirectories = true
                    panel.allowsMultipleSelection = false

                    if panel.runModal() == .OK, let url = panel.url {
                        Task {
                            await mixerVM.loadFolder(url: url)
                        }
                    }
                }

                Button("Play") {
                    mixerVM.play()
                }

            }

            // 🔹 GLOBAL PLAYHEAD CONTAINER
            ZStack(alignment: .topLeading) {

                List {
                    ForEach(mixerVM.tracks) { track in
                        TrackRow(
                            track: track,
                            controlColumnWidth: controlColumnWidth,
                            waveformHeight: waveformHeight,
                            onMute: { mixerVM.toggleMute(track) },
                            onSolo: { mixerVM.toggleSolo(track) },
                            onVolumeChange: { mixerVM.setVolume($0, for: track) }
                        )
                    }
                }

                

                // MARK: - SINGLE GLOBAL PLAYHEAD
                if mixerVM.hasLoadedTracks {
                    GeometryReader { geo in
                        let waveformWidth =
                            geo.size.width - controlColumnWidth - 12

                        let x =
                            controlColumnWidth + 12 +
                            waveformWidth * mixerVM.playhead

                        Rectangle()
                            .fill(Color.white.opacity(0.85))
                            .frame(width: playheadWidth)
                            .offset(x: x)
                            .allowsHitTesting(false)

                        Text(mixerVM.currentTimeText)
                            .font(.caption2.monospacedDigit())
                            .foregroundColor(.white)
                            .padding(4)
                            .background(Color.black.opacity(0.7))
                            .cornerRadius(4)
                            .offset(x: x - 20, y: -18)
                    }
                }



            }
            .frame(minHeight: 300)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
